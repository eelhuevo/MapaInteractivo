import enhance, json, os
M = enhance.build_materials()
jobs = [('edificio.glb','edificio.glb'),('oficinas.glb','oficinas.glb'),
 ('TorreAntiguaBanos.glb','torre-antigua-banos.glb'),('TorreAntiguaConexion.glb','torre-antigua-conexion.glb'),
 ('TorreAntiguaCursos.glb','torre-antigua-cursos.glb'),('TorreInnovacionCasilleros.glb','torre-innovacion-plantilla.glb'),
 ('TorreInnovacionConexion.glb','torre-innovacion-pisos-6-10.glb')]
log={}
for s,d in jobs:
    st = enhance.process('models/'+s,'out/'+d,M,log)
    print(d, os.path.getsize('out/'+d)//1024,'KB', st, flush=True)
json.dump(log,open('out/log.json','w'),indent=1,default=str)
