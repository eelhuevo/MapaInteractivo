import trimesh, numpy as np, re, os, sys, io, warnings, json
from PIL import Image
from trimesh.visual.material import PBRMaterial
from trimesh.visual import TextureVisuals
warnings.filterwarnings('ignore')

# ----------------------------------------------------------------------------
# Texturas procedurales (tileables) -- se pueden ajustar los colores aqui
# ----------------------------------------------------------------------------
PALETA = dict(
    pared=(236, 232, 224),
    zocalo=(88, 90, 96),
    piso=(190, 188, 183),
    junta=(150, 148, 144),
    techo=(242, 242, 238),
    madera_puerta=(150, 104, 66),
    madera_oscura=(96, 64, 42),
    madera_piso=(168, 122, 82),
    laminado=(205, 211, 216),
    metal=(172, 174, 178),
    hormigon=(165, 164, 160),
)


def fnoise(h, w, seed, power=1.2, aniso=(0.0, 0.0)):
    """Ruido 1/f periodico (tileable). aniso=(ay, ax) suaviza en esa direccion."""
    r = np.random.default_rng(seed)
    F = np.fft.fft2(r.standard_normal((h, w)))
    fy = np.fft.fftfreq(h)[:, None]
    fx = np.fft.fftfreq(w)[None, :]
    f = np.sqrt(fx ** 2 + fy ** 2)
    f[0, 0] = 1
    F = F / f ** power
    F *= np.exp(-((fy * aniso[0]) ** 2 + (fx * aniso[1]) ** 2))
    F[0, 0] = 0
    o = np.real(np.fft.ifft2(F))
    return (o - o.min()) / (o.max() - o.min() + 1e-9)


def to_img(arr, q=88):
    im = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), 'RGB')
    b = io.BytesIO()
    im.save(b, 'JPEG', quality=q)
    b.seek(0)
    out = Image.open(b)
    out.load()
    return out


def tint(base, n, amp):
    base = np.array(base, float)
    return base[None, None, :] * (1 + (n[:, :, None] - 0.5) * amp)


def tex_piso(N=512):
    a = tint(PALETA['piso'], fnoise(N, N, 1, 1.6), 0.10)
    half = N // 2
    for ty in range(2):
        for tx in range(2):  # variacion por baldosa
            a[ty * half:(ty + 1) * half, tx * half:(tx + 1) * half] *= 1 + (np.random.default_rng(ty * 2 + tx).random() - 0.5) * 0.05
    sp = fnoise(N, N, 9, 0.2)
    a *= (1 + (sp[:, :, None] - 0.5) * 0.06)
    g = 3
    for k in (0, half):
        a[k - g:k + g if k else N, :] = a[k - g:k + g if k else N, :] * 0 + PALETA['junta']
        a[:, k - g:k + g if k else N] = PALETA['junta']
    a[:g, :] = PALETA['junta']; a[:, :g] = PALETA['junta']
    return to_img(a)


def tex_pared(W=256, H=512):
    a = tint(PALETA['pared'], fnoise(H, W, 2, 1.8), 0.05)
    zoc = int(H * 0.12 / 3.6)  # 12 cm de zocalo
    a[H - zoc:, :] = tint(PALETA['zocalo'], fnoise(zoc, W, 3, 1.0), 0.08)[0:zoc]
    a[H - zoc - 2:H - zoc, :] = (190, 186, 178)  # remate
    return to_img(a)


def tex_techo(N=512):
    a = tint(PALETA['techo'], fnoise(N, N, 4, 1.4), 0.06)
    pf = fnoise(N, N, 5, 0.1)
    a *= (1 + (pf[:, :, None] - 0.5) * 0.08)
    half = N // 2
    for k in (0, half):
        a[max(k - 3, 0):k + 3, :] = (196, 196, 192)
        a[:, max(k - 3, 0):k + 3] = (196, 196, 192)
    a[N - 3:, :] = (196, 196, 192); a[:, N - 3:] = (196, 196, 192)
    return to_img(a)


def _grain(N, base, seed, vertical=True, contrast=0.55):
    n = fnoise(N, N, seed, 1.0, aniso=(70, 0) if vertical else (0, 70))
    n2 = fnoise(N, N, seed + 50, 1.6)
    a = tint(base, n, contrast)
    a *= (1 + (n2[:, :, None] - 0.5) * 0.15)
    return a


def tex_madera(base, seed, N=512):
    return to_img(_grain(N, base, seed, True))


def tex_madera_piso(N=512):
    a = _grain(N, PALETA['madera_piso'], 31, False)
    for k in range(0, N, N // 8):  # tablones
        a[k:k + 2, :] *= 0.55
    return to_img(a)


def tex_metal(N=256):
    n = fnoise(N, N, 6, 0.8, aniso=(0, 90))
    return to_img(tint(PALETA['metal'], n, 0.22))


def tex_laminado(N=256):
    return to_img(tint(PALETA['laminado'], fnoise(N, N, 7, 1.5), 0.05))


def tex_hormigon(N=512):
    a = tint(PALETA['hormigon'], fnoise(N, N, 8, 1.7), 0.22)
    return to_img(a)


def tex_asfalto(N=512):
    a = tint((92, 94, 98), fnoise(N, N, 12, 1.2), 0.25)
    return to_img(a)


def tex_fachada(N=512):
    a = tint((200, 196, 188), fnoise(N, N, 13, 1.6), 0.12)
    half = N // 2
    for k in (0, half):
        a[max(k - 2, 0):k + 2, :] *= 0.8
    return to_img(a)


def pbr(name, img, rough=0.8, metal=0.0, factor=(255, 255, 255, 255)):
    return PBRMaterial(name=name, baseColorTexture=img, baseColorFactor=list(factor),
                       metallicFactor=metal, roughnessFactor=rough, doubleSided=False)


def build_materials():
    M = {}
    M['piso'] = pbr('piso_porcelanato', tex_piso(), 0.35)
    M['pared'] = pbr('pared_pintura', tex_pared(), 0.92)
    M['techo'] = pbr('techo_placa_acustica', tex_techo(), 0.95)
    M['puerta'] = pbr('puerta_madera', tex_madera(PALETA['madera_puerta'], 21), 0.55)
    M['madera_oscura'] = pbr('madera_oscura', tex_madera(PALETA['madera_oscura'], 22), 0.5)
    M['madera_piso'] = pbr('madera_piso', tex_madera_piso(), 0.5)
    M['cabina'] = pbr('cabina_laminado', tex_laminado(), 0.4)
    M['metal'] = pbr('metal_cepillado', tex_metal(), 0.38, 0.9)
    M['hormigon'] = pbr('hormigon', tex_hormigon(), 0.9)
    M['asfalto'] = pbr('pavimento', tex_asfalto(), 0.95)
    M['fachada'] = pbr('fachada', tex_fachada(), 0.85)
    M['espejo'] = PBRMaterial(name='espejo', baseColorFactor=[205, 222, 232, 255], metallicFactor=1.0, roughnessFactor=0.04)
    M['senal'] = PBRMaterial(name='senaletica', baseColorFactor=[30, 140, 90, 255], metallicFactor=0.0, roughnessFactor=0.6)
    M['vidrio'] = PBRMaterial(name='vidrio', baseColorFactor=[170, 205, 220, 90], metallicFactor=0.0, roughnessFactor=0.05, alphaMode='BLEND')
    return M


# escalas (metros por repeticion de textura): (su, sv)
SCALE = dict(piso=(1.2, 1.2), pared=(2.0, 3.6), techo=(1.2, 1.2), puerta=(1.0, 1.0), madera_oscura=(1.0, 1.0),
             madera_piso=(1.0, 1.0), cabina=(1.0, 1.0), metal=(1.0, 1.0), hormigon=(1.5, 1.5), asfalto=(3.0, 3.0),
             fachada=(1.0, 1.0), espejo=(1, 1), senal=(1, 1), vidrio=(1, 1))
NO_UV = ('espejo', 'senal', 'vidrio')

KEEP_MAT = re.compile(r'Vending|Glass|Buttons|Black_Letters|Main Materials|Money|Cast_Iron|Display|Screen|Coin', re.I)


def node_key(n):
    k = re.sub(r'[._ ]?\d+.*$', '', n)
    return re.sub(r'_[0-9a-f]{6}$', '', k)


EDIFICIO = False
EDIF_MAP = {'Material.009': 'asfalto', 'Material.010': 'piso', 'Material.011': 'hormigon',
            'Material.001': 'fachada', 'Material.002': 'fachada', 'Material.003': 'fachada', 'Material.012': 'fachada',
            'Material.004': 'hormigon', 'Material.005': 'metal', 'Material.006': 'metal', 'Material.007': 'metal', 'Material.008': 'metal'}


def classify(n, mat, ext, bmin, bmax):
    k = node_key(n)
    mn = mat or ''
    if EDIFICIO:
        return EDIF_MAP.get(mn, 'fachada')
    h = ext[1]
    horiz = max(ext[0], ext[2])
    if k in ('cortar', 'Restar'):
        return 'helper'
    if k in ('Piso', 'Plano'):
        return 'piso'
    if k in ('Paredes',):
        return 'pared'
    if k in ('Cubo', 'Cube'):
        if h < 0.3 and horiz > 1:
            return 'piso'
        return 'pared'
    if k in ('Door_left', 'Door_right', 'DOOR'):
        return 'puerta'
    if k == 'Cabin':
        return 'cabina'
    if k == 'Mirror_main':
        return 'espejo'
    if k in ('arrow_up', 'arrow_down', 'n'):
        return 'senal'
    if k == 'Stair':
        if mn.lower().startswith('wood'):
            return 'madera_piso'
        if mn.lower().startswith('metal'):
            return 'metal'
        return 'hormigon'
    if k in ('Text',):
        return 'keep'
    if KEEP_MAT.search(mn) or k in ('Vending Machine', 'Box'):
        return 'keep'
    if k == 'Helpders':
        return 'cabina'
    if k == 'Cilindro':
        return 'hormigon'
    if mn.startswith('Nerez') or k == 'Cylinder':
        return 'metal'
    if mn.startswith('Drevo'):
        return 'madera_oscura'
    if k == 'Plane':
        return 'madera_oscura' if h > 1.5 else 'metal'
    # geometria
    if h < 0.3 and horiz > 1.5:
        return 'piso'
    if h > 1.8 and min(ext[0], ext[2]) < 0.8:
        return 'pared'
    return 'pared'


def transform_mesh(g, T):
    R = T[:3, :3]
    V = g.vertices @ R.T + T[:3, 3]
    F = g.faces.copy()
    if np.linalg.det(R) < 0:  # espejo (escala negativa): corregir el sentido de las caras
        F = F[:, ::-1]
    return V, F


def face_normals(V, F):
    t = V[F]
    n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    ln = np.linalg.norm(n, axis=1)
    bad = ln < 1e-12
    ln[bad] = 1
    n = n / ln[:, None]
    n[bad] = (0, 1, 0)
    return n


def make_uv(P, N, su, sv, y0, clip_top):
    horiz = np.abs(N[:, 1]) >= 0.6
    t = np.stack([-N[:, 2], np.zeros(len(N)), N[:, 0]], 1)
    tn = np.linalg.norm(t, axis=1)
    tn[tn < 1e-6] = 1
    t = t / tn[:, None]
    u = np.where(horiz, P[:, 0], (P * t).sum(1))
    v = np.where(horiz, P[:, 2], P[:, 1] - y0)
    uv = np.stack([u / su, v / sv], 1)
    if clip_top:
        uv[:, 1] = np.clip(uv[:, 1], 0.0, 0.995)
    return uv


def process(src, dst, M, log):
    global EDIFICIO
    EDIFICIO = os.path.basename(src).startswith('edificio')
    sc = trimesh.load(src, force='scene')
    out = trimesh.Scene()
    stats = dict(roles={}, flipped=0, dup_faces=0, removed=[])
    pieces = []
    for n in sc.graph.nodes_geometry:
        T, gn = sc.graph[n]
        g = sc.geometry[gn]
        V, F = transform_mesh(g, T)
        if np.linalg.det(T[:3, :3]) < 0:
            stats['flipped'] += 1
        mat = getattr(getattr(g.visual, 'material', None), 'name', None)
        ext = V.max(0) - V.min(0)
        pieces.append(dict(n=n, g=g, V=V, F=F, mat=mat, ext=ext, bmin=V.min(0), bmax=V.max(0)))

    walls = [p for p in pieces if node_key(p['n']) == 'Paredes' or (node_key(p['n']) == 'Cubo' and p['ext'][1] > 1.5)]
    floor_y = None
    wall_top = None
    if walls:
        wall_top = float(np.median([p['bmax'][1] for p in walls]))

    for p in pieces:
        role = classify(p['n'], p['mat'], p['ext'], p['bmin'], p['bmax'])
        V, F = p['V'], p['F']
        if role == 'helper':
            dup = False
            for w in walls:
                lo = np.maximum(w['bmin'], p['bmin']); hi = np.minimum(w['bmax'], p['bmax'])
                inter = np.prod(np.clip(hi - lo, 0, None))
                vol = np.prod(np.maximum(p['ext'], 1e-6))
                if inter / vol > 0.5:
                    dup = True; break
            if dup:
                stats['removed'].append(p['n']); continue
            role = 'pared'
        # caras duplicadas (z-fighting)
        key = np.sort(F, axis=1)
        _, idx = np.unique(key, axis=0, return_index=True)
        if len(idx) < len(F):
            stats['dup_faces'] += len(F) - len(idx)
            F = F[np.sort(idx)]
        if role == 'keep':
            vis = p['g'].visual.copy() if len(idx) == len(p['F']) else None
            m = trimesh.Trimesh(vertices=V, faces=F, visual=vis, process=False) if vis is not None else trimesh.Trimesh(vertices=V, faces=F, process=False)
            if vis is None:
                m.visual = p['g'].visual.copy() if False else m.visual
            out.add_geometry(m, node_name=p['n'], geom_name=p['n'])
            stats['roles']['conservado'] = stats['roles'].get('conservado', 0) + 1
            continue
        stats['roles'][role] = stats['roles'].get(role, 0) + 1
        small_round = node_key(p['n']) in ('Cylinder', 'Cilindro')
        if small_round:
            m = trimesh.Trimesh(vertices=V, faces=F, process=False)
            Nv = m.vertex_normals
            P = V; Nn = Nv
        else:
            Vu = V[F].reshape(-1, 3)
            Fu = np.arange(len(F) * 3).reshape(-1, 3)
            fn = face_normals(V, F)
            if role == 'piso' and fn[:, 1].mean() < 0:  # piso mirando hacia abajo
                Fu = Fu[:, ::-1]; fn = -fn
                stats['flipped_floor'] = stats.get('flipped_floor', 0) + 1
            m = trimesh.Trimesh(vertices=Vu, faces=Fu, process=False)
            P = Vu; Nn = np.repeat(fn, 3, axis=0)
        su, sv = SCALE[role]
        y0 = float(V[:, 1].min())
        uv = make_uv(P, Nn, su, sv, y0, clip_top=(role == 'pared'))
        if role in NO_UV:
            m.visual = TextureVisuals(uv=np.zeros((len(P), 2)), material=M[role])
        else:
            m.visual = TextureVisuals(uv=uv, material=M[role])
        out.add_geometry(m, node_name=p['n'], geom_name=p['n'])
    out.export(dst, file_type='glb')

    # techo opcional (solo si hay un Piso grande con huella real)
    techo_path = None
    pisos = [p for p in pieces if node_key(p['n']) == 'Piso' and len(p['F']) > 100]
    if pisos and wall_top is not None:
        pz = pisos[0]
        V, F = pz['V'].copy(), pz['F']
        V[:, 1] = wall_top
        F = F[:, ::-1]
        Vu = V[F].reshape(-1, 3); Fu = np.arange(len(F) * 3).reshape(-1, 3)
        fn = face_normals(Vu.reshape(-1, 3)[Fu.reshape(-1)].reshape(-1, 3), np.arange(len(Vu)).reshape(-1, 3))
        uv = make_uv(Vu, np.repeat(fn, 3, axis=0), 1.2, 1.2, 0, False)
        tm = trimesh.Trimesh(vertices=Vu, faces=Fu, process=False)
        tm.visual = TextureVisuals(uv=uv, material=M['techo'])
        ts = trimesh.Scene(); ts.add_geometry(tm, node_name='Techo', geom_name='Techo')
        techo_path = dst.replace('.glb', '-techo.glb')
        ts.export(techo_path, file_type='glb')
        stats['techo_y'] = round(wall_top, 2)
    log[os.path.basename(src)] = stats
    return stats


if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]
    M = build_materials()
    log = {}
    print(process(src, dst, M, log))
